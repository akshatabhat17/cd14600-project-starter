import io
import unittest
from contextlib import redirect_stdout

from balance.balance import Balance
from balance.balance_observer import PrintObserver
from transaction.transaction import Transaction
from transaction.transaction_category import TransactionCategory


class TestPrintObserver(unittest.TestCase):

    def setUp(self):
        self.balance = Balance.get_instance()
        self.balance.clear_observers()
        self.balance.reset()

    def tearDown(self):
        self.balance.clear_observers()

    def test_print_observer_runs_after_balance_change(self):
        observer = PrintObserver()
        self.balance.register_observer(observer)
        output = io.StringIO()

        with redirect_stdout(output):
            self.balance.apply_transaction(
                Transaction(25, TransactionCategory.INCOME)
            )

        self.assertIn("Balance updated:", output.getvalue())
        self.assertIn("$25.00", output.getvalue())
