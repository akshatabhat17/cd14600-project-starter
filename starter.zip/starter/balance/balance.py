# balance.py

import threading

from transaction.transaction_category import TransactionCategory
from transaction.transaction_strategy import TransactionProcessor

class Balance:
    """Singleton to track the balance."""

    _instance = None
    _lock = threading.Lock()

    def __init__(self):
        """Initialize the balance once."""
        if getattr(self, "_initialized", False):
            return
        self._balance = 0.0
        self._observers = []
        self._transaction_processor = TransactionProcessor()
        self._initialized = True

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def get_instance(cls):
        """Return the application's one Balance instance."""
        return cls()

    def reset(self):
        """Reset the net balance to zero."""
        self._balance = 0.0
        self._notify_observers(None)

    def add_income(self, amount):
        """Add income to the balance."""
        self._balance += amount
        if not getattr(self, "_applying_transaction", False):
            self._notify_observers(None)

    def add_expense(self, amount):
        """Subtract expense from the balance."""
        self._balance -= amount
        if not getattr(self, "_applying_transaction", False):
            self._notify_observers(None)

    def apply_transaction(self, transaction):
        """
        Apply a Transaction object to update the balance.

        Args:
            transaction (Transaction): The transaction to apply.
        """
        if not isinstance(transaction.category, TransactionCategory):
            raise ValueError("Invalid transaction category")
        self._applying_transaction = True
        try:
            self._transaction_processor.apply(self, transaction)
        finally:
            self._applying_transaction = False
        self._notify_observers(transaction)

    def get_balance(self):
        """Get the current net balance."""
        return self._balance

    def summary(self):
        """Return a summary string of the net balance."""
        return f"Balance: ${self._balance:.2f}"

    def register_observer(self, observer):
        """Register an observer that is notified after balance changes."""
        if observer not in self._observers:
            self._observers.append(observer)

    def unregister_observer(self, observer):
        """Unregister a balance observer."""
        if observer in self._observers:
            self._observers.remove(observer)

    def clear_observers(self):
        """Remove all registered balance observers."""
        self._observers.clear()

    def set_transaction_processor(self, processor):
        """Replace the transaction processing strategy."""
        self._transaction_processor = processor

    def _notify_observers(self, transaction):
        for observer in list(self._observers):
            observer.update(self._balance, transaction)
    
