import unittest

from balance.balance import Balance
from transaction.transaction import Transaction
from transaction.transaction_category import TransactionCategory


class TestTransactionStrategy(unittest.TestCase):

    def setUp(self):
        self.balance = Balance.get_instance()
        self.balance.clear_observers()
        self.balance.reset()

    def test_income_and_expense_strategies(self):
        self.balance.apply_transaction(
            Transaction(300, TransactionCategory.INCOME)
        )
        self.balance.apply_transaction(
            Transaction(125, TransactionCategory.EXPENSE)
        )
        self.assertEqual(self.balance.get_balance(), 175)


if __name__ == "__main__":
    unittest.main()
