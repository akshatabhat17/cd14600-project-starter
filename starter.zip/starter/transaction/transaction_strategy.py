from transaction.transaction_category import TransactionCategory


class TransactionStrategy:
    """Interface for applying a transaction to a balance."""

    def apply(self, balance, transaction):
        raise NotImplementedError


class IncomeStrategy(TransactionStrategy):
    def apply(self, balance, transaction):
        balance.add_income(transaction.amount)


class ExpenseStrategy(TransactionStrategy):
    def apply(self, balance, transaction):
        balance.add_expense(transaction.amount)


class TransactionProcessor:
    """
    Strategy context that selects how a transaction changes the balance.

    Replacing or registering a strategy keeps the balance decoupled from
    income and expense rules.
    """

    def __init__(self):
        self.strategies = {
            TransactionCategory.INCOME: IncomeStrategy(),
            TransactionCategory.EXPENSE: ExpenseStrategy(),
        }

    def register_strategy(self, category, strategy):
        self.strategies[category] = strategy

    def apply(self, balance, transaction):
        strategy = self.strategies.get(transaction.category)
        if strategy is None:
            raise ValueError("Invalid transaction category")
        strategy.apply(balance, transaction)
