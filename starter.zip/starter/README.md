# Personal Finance Manager

This application demonstrates four object-oriented design patterns.

## Implemented patterns

- **Singleton:** `Balance` is the application's single source of truth. It keeps every
  transaction and observer attached to the same balance state.
- **Adapter:** `TransactionAdapter` translates third-party
  `ExternalFreelanceIncome` values into internal `Transaction` objects.
- **Observer:** `PrintObserver` reports every balance change and
  `LowBalanceAlertObserver` reports when a balance falls below a configured
  threshold.
- **Strategy (student choice):** `TransactionProcessor` selects an income or
  expense strategy for each transaction. This separates transaction rules from
  balance bookkeeping, makes new transaction types easier to add, and allows
  strategies to be substituted independently in tests.

## Reflection

The patterns improve separation of responsibilities: the balance owns state,
transactions describe events, the adapter protects the application from external
format changes, observers react without coupling the balance to UI output, and
strategies keep category-specific behavior extensible.

The trade-off is additional classes and indirection. In this small application,
the extra abstraction is intentionally modest, but it demonstrates how the
system can grow. For example, additional transaction categories can be added
by registering a strategy instead of expanding a large conditional in the
balance class.

## Run

From this folder:

```bash
python main.py
python -m unittest discover
```
